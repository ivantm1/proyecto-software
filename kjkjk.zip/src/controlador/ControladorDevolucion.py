from PyQt5.QtWidgets import QMessageBox
from src.modelo.logica.LoggerSingleton import Logger

class ControladorDevolucion:
    def __init__(self, ref_modelo, ref_vista_devolucion, ref_vista_bibliotecario):
        self._modelo      = ref_modelo
        self._vista       = ref_vista_devolucion
        self._vista_anterior = ref_vista_bibliotecario

    def registrarDevolucion(self, isbn, estado_libro):
        if not isbn:
            self._vista.lanzarAviso("Por favor, introduce un ISBN válido.")
            return

        prestamo = self._modelo.buscarPrestamoActivoPorISBN(isbn)
        if prestamo is None:
            self._vista.lanzarAviso("No se encontró ningún préstamo activo con ese ISBN.")
            return

        exito = self._modelo.registrarDevolucion(isbn)
        if not exito:
            Logger().devolucion_error(isbn)
            self._vista.lanzarAviso("Error al registrar la devolución. Inténtalo de nuevo.")
            return

        semanas_retraso = self._modelo.calcularSemanasRetraso(prestamo.fecha_devolucion)
        Logger().devolucion_ok(isbn, prestamo.correo_estudiante, semanas_retraso)

        mensajes = []
        if semanas_retraso > 0:
            self._modelo.aplicarSancionRetraso(prestamo.correo_estudiante, semanas_retraso)
            Logger().sancion_aplicada(
                prestamo.correo_estudiante,
                "retraso",
                f"semanas={semanas_retraso} isbn={isbn}"
            )
            mensajes.append(f"Devolución registrada con {semanas_retraso} semana(s) de retraso.")
            mensajes.append("Se ha aplicado una sanción por retraso al estudiante.")
            
        if estado_libro in ["Dañado", "Roto"]:
            sancion = self._modelo.aplicarSancionDanio(prestamo.correo_estudiante, estado_libro)
            if sancion:
                Logger().sancion_aplicada(
                    prestamo.correo_estudiante,
                    estado_libro.lower(),
                    f"isbn={isbn}"
                )
                mensajes.append(f"El libro está {estado_libro.lower()}: se ha aplicado una sanción de daño.")
            else:
                mensajes.append(f"El libro está {estado_libro.lower()}: no se pudo aplicar la sanción automática.")

        if not mensajes:
            mensaje = "Devolución registrada correctamente."
        else:
            mensaje = "\n".join(mensajes)

        self._vista.mostrarResultado(mensaje)
        self._vista.lanzarAviso(mensaje)

        reserva = self._modelo.obtenerReservaPorLibro(isbn)
        if reserva:
            self._modelo.marcarReservaEspera(isbn)
            QMessageBox.information(
                self._vista,
                "Libro con reserva",
                f"El libro devuelto tiene una reserva activa del alumno {reserva.correo_estudiante}.\n"
                "La reserva ha pasado a estado 'Espera'. El alumno tiene 7 días para recoger el libro.\n"
                "Si no lo recoge en ese plazo, la reserva se cancelará automáticamente."
            )

        self._vista.limpiarFormulario()

    def volver(self):
        self._vista.limpiarFormulario()
        self._vista.close()
        self._vista_anterior.showMaximized()