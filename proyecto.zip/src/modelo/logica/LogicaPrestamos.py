from src.modelo.dao.PrestamoDaoJDBC import PrestamoDaoJDBC
from src.modelo.dao.LibroDaoJDBC import LibroDaoJDBC
from src.modelo.dao.ReservaDaoJDBC import ReservaDaoJDBC
from src.modelo.dao.SancionDaoJDBC import SancionDaoJDBC

class LogicaPrestamos:
    """Responsabilidad: ciclo de vida y consultas de préstamos."""

    MAX_PRESTAMOS_ACTIVOS = 7

    def registrarPrestamo(self, isbn, correo_estudiante):
        return PrestamoDaoJDBC().registrarPrestamo(isbn, correo_estudiante)

    def registrarDevolucion(self, isbn):
        return PrestamoDaoJDBC().registrarDevolucion(isbn)

    def buscarPrestamoActivoPorISBN(self, isbn):
        return PrestamoDaoJDBC().buscarPrestamoActivoPorISBN(isbn)

    def tieneCooldown(self, correo_estudiante, isbn):
        return PrestamoDaoJDBC().tieneCooldown(correo_estudiante, isbn)

    def obtenerPrestamosEstudiante(self, correo_estudiante):
        return PrestamoDaoJDBC().obtenerPrestamosEstudiante(correo_estudiante)

    def obtenerPrestamosProximos(self, correo_estudiante):
        return PrestamoDaoJDBC().obtenerPrestamosProximos(correo_estudiante)

    def prorrogarPrestamo(self, isbn):
        return PrestamoDaoJDBC().prorrogarPrestamo(isbn)

    def contarPrestamosEstudiante(self, correo_estudiante):
        return PrestamoDaoJDBC().contarPrestamosEstudiante(correo_estudiante)

    def buscarPrestamosEstudiante(self, correo_estudiante, titulo='', tema='Ninguno'):
        return PrestamoDaoJDBC().buscarPrestamosEstudiante(correo_estudiante, titulo, tema)

    def tienePrestamoActivo(self, isbn, correo_estudiante):
        return PrestamoDaoJDBC().tienePrestamoActivo(isbn, correo_estudiante)

    def validarPrestamo(self, isbn, correo_estudiante):
        if SancionDaoJDBC().tieneSancionActiva(correo_estudiante):
            return False, "Este estudiante tiene una sanción activa y no puede realizar préstamos."

        if self.contarPrestamosEstudiante(correo_estudiante) >= self.MAX_PRESTAMOS_ACTIVOS:
            return False, f"Este estudiante ya tiene {self.MAX_PRESTAMOS_ACTIVOS} préstamos activos. No puede tener más de {self.MAX_PRESTAMOS_ACTIVOS} a la vez."

        if self.tieneCooldown(correo_estudiante, isbn):
            return False, "Este estudiante devolvió este libro hace menos de 7 días. Debe esperar antes de volver a pedirlo."

        libro = LibroDaoJDBC().buscarPorISBN(isbn)
        if libro is None:
            return False, "No se encontró el libro con ese ISBN."

        disponibilidad = str(libro.disponibilidad).lower()
        if disponibilidad == 'prestado':
            return False, "No es posible prestar el libro porque ya está prestado."

        if disponibilidad == 'reservado':
            if ReservaDaoJDBC().reservaExpirada(isbn):
                ReservaDaoJDBC().cancelarReserva(isbn)
                LibroDaoJDBC().restaurarLibro(isbn)
            else:
                return False, "No es posible prestar el libro porque está reservado."
        elif disponibilidad != 'disponible':
            return False, "No es posible prestar el libro porque no está disponible."

        return True, ""
